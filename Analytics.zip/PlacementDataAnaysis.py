# -*- coding: utf-8 -*-
"""
Created on Mon Dec 31 03:19:34 2018

@author: RTR
"""

#Student Placement Data Analysis
#Class, Inheritance, Override, Dunder, Decarators,

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
'''
class Placement():
    
    
    
    def __init__(self):
        pass
    
    def __repr__(self):
        print(self)
'''    
    
#st = pd.ExcelFile("C:\\Users\\RTR\\Desktop\\python\\Student1.xlsx")    
#st1 = pd.read_excel("C:\\Users\\RTR\\Desktop\\python\\Student1.xlsx") 

'''
read_sheet_name = st.sheet_names
#print(read_sheet_name)
st1["Package"].max()
a = st1["Package"]
st1.describe()
st1
st1.head()
st1.tail()
st1[2:6]
st1[["Name","Package"]]
st1.columns
st1.query('["Yes"] in PlacementStatus')
st1.sort_values("Name", ascending = "True")
st1.sort_values(["Package" , "Name"])
#str(st1["Company"])
st1["Company"].fillna("NoCompany")
st1["Package"].fillna(0)
c = st1.query('["Yes"] in PlacementStatus')
#print(c)


'''

class Placement:
    
    
    st1 = pd.read_excel("C:\\Users\\RTR\\Desktop\\python\\Student1.xlsx")
    
    def pieChart():
        #st1.query('["Yes"] in PlacementStatus')
        piee = plt.pie(st1["Package"],labels=st1["Company"])
        
        
        
    def histogramChart():
        f=len(st1.query('["No"] in PlacementStatus'))
        e=len(st1.query('["Yes"] in PlacementStatus'))
        print(plt.hist((e, f), bins =[2,3,4,5,6,7,8],label=["No","Yes"]))
    
    def barChart():
        d=np.arange(len(st1["Company"]))
        p = st1["Package"]
        #plt.xlabel=("Company")
        print(plt.bar(d,p))
        print(plt.scatter(p,d))
        print(plt.plot(p,d))
        
    def __repr__(self):
        print("Placement Data")



Placement.barChart()
Placement.histogramChart()
Placement.pieChart()











